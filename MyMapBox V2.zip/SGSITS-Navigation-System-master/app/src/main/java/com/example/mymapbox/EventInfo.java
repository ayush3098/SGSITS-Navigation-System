package com.example.mymapbox;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EventInfo extends AppCompatActivity {
DBhelper myDb;
EditText date;
Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_info);
        myDb=new DBhelper(this);
        date=(EditText)findViewById(R.id.date);
        button2=(Button)findViewById(R.id.button2);
        viewAll();

    }
    public void viewAll() {
        button2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                       if(res.getCount() == 0) {
                            // show message
                            showMessage("Error","Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            if (res.getString(2).equals(date.getText().toString())) {

                                buffer.append("Event :" + res.getString(1) + "\n");
                                buffer.append("Date :" + res.getString(2) + "\n");
                                buffer.append("Location :" + res.getString(3) + "\n\n");


                            }
                        }



                        // Show all data
                        showMessage("Event Info",buffer.toString());
                    }
                }
        );
    }
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}
