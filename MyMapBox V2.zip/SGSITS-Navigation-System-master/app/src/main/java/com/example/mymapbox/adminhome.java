package com.example.mymapbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class adminhome extends AppCompatActivity {
    DBhelper myDb;
    EditText event;
    EditText eventdate;
  EditText location;
    EditText time;
    EditText club;
    Button addevent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminhome);
        myDb = new DBhelper(this);
        event = (EditText) findViewById(R.id.event);
        eventdate = (EditText) findViewById(R.id.eventdate);
        location = (EditText) findViewById(R.id.location);
        addevent=(Button)findViewById(R.id.addevent);
        AddEvent();

    }

    public  void AddEvent() {
        addevent.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Log.i("hey","bookid.getText().toString()");
                        boolean isInserted = myDb.insertData(event.getText().toString(), eventdate.getText().toString(),
                                location.getText().toString());
                        if (isInserted == true)
                            Toast.makeText(adminhome.this, "Event Added", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(adminhome.this, "Event not Added", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
}