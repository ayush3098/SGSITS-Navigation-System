package com.example.mymapbox;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginAdmin extends AppCompatActivity {

    private EditText uname;
    private EditText password;
    private Button button3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_admin);
        uname = (EditText) findViewById(R.id.uname);
        password = (EditText) findViewById(R.id.password);
        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (uname.getText().toString().equals("admin") && password.getText().toString().equals("123")) {
                   Intent intent;
                    intent = new Intent(LoginAdmin.this, adminhome.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(getApplicationContext(),"incorrect details", Toast.LENGTH_LONG).show();
            }
        });


    }
}




