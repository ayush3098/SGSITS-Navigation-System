package com.example.mymapbox;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBhelper extends SQLiteOpenHelper {
    public static final String Database_Name="Event.db";
    public static final String Table_Name="Events";

    public static final String Col_1="Id";
    public static final String Col_2="Event";

    public static final String Col_3="Date";
    public static final String Col_4="Location";
    //public static final String Col_5="Time";
   // public static final String Col_6="Club";




    public DBhelper(@Nullable Context context) {
        super(context, Database_Name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Events(Id INTEGER PRIMARY KEY AUTOINCREMENT, Event TEXT, Date TEXT, Location TEXT, Time TEXT, Club TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("Drop Table if Exists Events");
        onCreate(db);

    }
    public boolean insertData(String event,String eventdate, String location){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(Col_2,event);
        contentValues.put(Col_3,eventdate);
        contentValues.put(Col_4,location);
       // contentValues.put(Col_5,time);
       // contentValues.put(Col_6,club);
        long result = db.insert(Table_Name,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;

    }
    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+Table_Name,null);
        return res;
    }
}
